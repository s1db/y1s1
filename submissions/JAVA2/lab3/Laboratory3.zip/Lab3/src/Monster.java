public class Monster {
	// TODO: Put your code here
}
