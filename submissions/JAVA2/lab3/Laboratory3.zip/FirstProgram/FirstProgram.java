/**
 * A simple Hello World example program for Java labs
 */
public class FirstProgram {

    public static void main(String[] args) {
        System.out.println("Hello there");
        System.out.println("Welcome to Java");

        System.out.println("Let's demonstrate a simple calculation");
        int answer = 2 + 2;
        System.out.println("2 + 2 is " + answer);
    }
}
